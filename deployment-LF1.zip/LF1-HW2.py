import json
import urllib.parse
import boto3
#from opensearchpy import OpenSearch, RequestsHttpConnection


def lambda_handler(event, context):
    print("Printing Lambda event")
    print(event)
    # Get the object from the event and show its content type
    print("PUT on s3 bucket triggered")
    bucket = event['Records'][0]['s3']['bucket']['name']
    print("BUCKET:", bucket)
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    print("KEY:",key)
    
    try:
        s3 = boto3.client('s3')
        response = s3.get_object(Bucket=bucket, Key=key)
        print("Printing get_object Response")
        print(response)
        print("CONTENT TYPE: " + response['ContentType'])
        
        rekognition = boto3.client('rekognition')
    
        response = rekognition.detect_labels(Image={'S3Object':{'Bucket':bucket,'Name':key}},
        MaxLabels=10,
        )
        
        print('Detected labels for ' + key)
        print()
        for label in response['Labels']:
            print("Label: " + label['Name'])
            print("Confidence: " + str(label['Confidence']))
        #return response['ContentType']
    except Exception as e:
        print(e)
        raise e
        
        
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps('Hello from Lambda!')
    # }
